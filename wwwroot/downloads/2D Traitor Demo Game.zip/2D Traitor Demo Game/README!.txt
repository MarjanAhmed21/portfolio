How to play:
Speak to the characters by pressing the SPACE bar and hearing what they have to say. Some will give you clues to help solve the case and figure out who the traitor in your circle is...

Move with the arrow keys.


Resources used:

Playable Character (all sprites, colour edits done by me):
https://www.spriters-resource.com/custom_edited/sonicthehedgehogcustoms/sheet/111947/

NPC1:
https://www.pinterest.fr/pin/361836151294120142/?d=t&mt=login

NPC2 (colour edits by me):
https://www.deviantart.com/triforcelegendx/art/Phoenix-Wright-Sprites-818039476

NPC3, NPC4, NPC5 (colour edits by me):
https://www.deviantart.com/triforcelegendx/art/Psi-Powerhouses-820610956

Video used to help make the dialogue box system:
https://www.youtube.com/watch?v=1NCvpZDtTMI
